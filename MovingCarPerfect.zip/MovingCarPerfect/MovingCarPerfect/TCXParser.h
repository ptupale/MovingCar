//
//  TCXParser.h
//  TCX Reader
//
//  Created by Jelle Vandebeeck on 11/01/12.
//  Copyright (c) 2012 fousa. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Parser.h"

@interface TCXParser : Parser
@end