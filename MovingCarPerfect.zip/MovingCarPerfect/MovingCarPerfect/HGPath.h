//
//  HGPath.h
//  MovingCar
//
//  Created by Pavankumar on 17/06/16.
//  Copyright © 2016 NissiCalvin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#define kPathLoadedNotification @"Path Loaded Notification"


@interface HGPath : NSObject
@property (readonly) MKMapPoint *points;
@property (readonly) NSUInteger pointCount;
@property (readonly)NSUInteger pointSpace;
@property (assign, nonatomic)CLLocationCoordinate2D coordinate;

-(id)initFromFile :(NSMutableArray *)array;
@end
