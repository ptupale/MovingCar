//
//  HGPath.m
//  MovingCar
//
//  Created by Pavankumar on 17/06/16.
//  Copyright © 2016 NissiCalvin. All rights reserved.
//

#import "HGPath.h"
#define INITIAL_POINT_SPACE 10000

@implementation HGPath
@synthesize pointCount,points,pointSpace;

-(id)initFromFile :(NSMutableArray *)array {
    if(self = [super init])
    {
        pointSpace = INITIAL_POINT_SPACE;
        points = malloc(sizeof(MKMapPoint) * pointSpace);
        pointCount = 0;
        [self performSelectorInBackground:@selector(processPathData:) withObject:array];
        
    }
    return self;
}

-(void)processPathData:(NSMutableArray *)data {
    for (NSString *string in data) {
        CLLocationCoordinate2D location = [self coordinateFromArray:string];
        if (!pointCount) {
            points[0] = MKMapPointForCoordinate(location);
            pointCount = 1;

        } else {
            points[pointCount] = MKMapPointForCoordinate(location);
            pointCount++;
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:kPathLoadedNotification object:self];

}

- (CLLocationCoordinate2D) coordinateFromArray : (NSString *)locationString
{
    
    NSString *str = [NSString stringWithFormat:@"%@",locationString];
    NSLog(@"Array values are : %lu",(unsigned long)str);
    __block  NSMutableArray* ar = [NSMutableArray array];
    [str enumerateSubstringsInRange:NSMakeRange(0, [str length]) options:NSStringEnumerationByWords usingBlock:^(NSString* word, NSRange wordRange, NSRange enclosingRange, BOOL* stop){
        [ar addObject:word];
    }];
    CLLocationDegrees latitude = [ar[0]doubleValue];
    CLLocationDegrees longitude = [ar[1]doubleValue];
    
    return   CLLocationCoordinate2DMake( latitude,  longitude);
}


@end
