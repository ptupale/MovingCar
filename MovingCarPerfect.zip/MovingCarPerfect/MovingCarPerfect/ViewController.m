//
//  ViewController.m
//  MovingCar
//
//  Created by Pavankumar on 17/06/16.
//  Copyright © 2016 NissiCalvin. All rights reserved.
//

#import "ViewController.h"
#import "GPXParser.h"
#import "HGPath.h"
#import <QuartzCore/QuartzCore.h>
#define degreesToRadians(x) (M_PI * x / 180.0)
#define radiandsToDegrees(x) (x * 180.0 / M_PI)

@interface ViewController ()
@property (strong, nonatomic) NSMutableArray *arrayOfTrackList;
@property (strong, nonatomic) NSArray *arrayForFileNames;
@property (strong, nonatomic) NSMutableArray *annot;
@property (readwrite)float *degreeGlobal;
@property (readwrite)MKMapPoint prevpoint;
@property (strong, nonatomic) NSMutableArray *arrayOfTrackListNew;
@property (readwrite)BOOL arrayVerification;


@end

@implementation ViewController
@synthesize arrayOfTrackList,arrayForFileNames,annot,prevpoint,arrayOfTrackListNew,arrayVerification,arrayOfTrackListHome;

- (void)viewDidLoad {
    [super viewDidLoad];
    arrayOfTrackList = [[NSMutableArray alloc]init];
    arrayOfTrackListNew = [[NSMutableArray alloc]init];
    arrayOfTrackListHome = [[NSMutableArray alloc]init];
    annot = [[NSMutableArray alloc]init];
    arrayForFileNames = @[@"gpxtest",@"ChennaiCentral",@"home"];
    [self dataForParsing:arrayForFileNames];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Button action

- (IBAction)addCarActon:(id)sender {
    dispatch_queue_t queueOne = dispatch_queue_create("first", NULL);
    dispatch_async(queueOne, ^{
        HGPath *path = [[HGPath alloc]initFromFile:arrayOfTrackList];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didLoadPath:) name:kPathLoadedNotification object:path];
    });
    dispatch_queue_t queueTwo = dispatch_queue_create("second", nil);
    dispatch_async(queueTwo, ^{
        HGPath *path = [[HGPath alloc] initFromFile:arrayOfTrackListNew];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didLoadPath:) name:kPathLoadedNotification object:path];
    });
    dispatch_queue_t queueThree = dispatch_queue_create("third", nil);
    dispatch_async(queueThree, ^{
        HGPath *path = [[HGPath alloc] initFromFile:arrayOfTrackListHome];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didLoadPath:) name:kPathLoadedNotification object:path];
    });


}

#pragma mark - Functions

- (void) didLoadPath : (NSNotification*) notification
{
    HGPath *path = (HGPath*)[notification object];
    NSLog(@"%lu",(unsigned long)path.pointCount);
    for (int i = 0; i < (unsigned long)path.pointCount; i++) {
        if (i>0) {
            prevpoint = path.points[i-1];
        }
        MKMapPoint mapPoint = path.points[i];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self setPosition:[NSValue valueWithPointer:&mapPoint] prevPoint:[NSValue valueWithPointer:&prevpoint]];
        });

        if (i==0) {
            MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
            MKCoordinateRegion region = MKCoordinateRegionMake(MKCoordinateForMapPoint(mapPoint), span);
            [self.theMapview setRegion:region animated:YES];

        }
        [NSThread sleepForTimeInterval:1.0];
        [self performSelectorOnMainThread:@selector(removePosition) withObject:nil waitUntilDone:NO];
    }

}

- (void) setPosition : (id) posValue prevPoint:(id)prevPoint ;
{
    NSLog(@"set position");
    
    MKMapPoint mapPoint = *(MKMapPoint*)[(NSValue*)posValue pointerValue];
    MKMapPoint mapPointTwo = *(MKMapPoint*)[(NSValue*)prevPoint pointerValue];
    CLLocationCoordinate2D coord = MKCoordinateForMapPoint(mapPoint);
    HGPath *ann = [[HGPath alloc]init];
    ann.coordinate = coord;
    [annot addObject:ann];
    [self.theMapview addAnnotations:annot];
        degreeGlobal = [self getHeadingForDirectionFromCoordinate:MKCoordinateForMapPoint(mapPointTwo) toCoordinate: MKCoordinateForMapPoint(mapPoint)];
    prevPoint = posValue;

}


-(void)removePosition {
    if (annot.count>0) {
        [self.theMapview removeAnnotation:annot[0]];
        [annot removeObjectAtIndex:0];
    }
    
}


- (float)getHeadingForDirectionFromCoordinate:(CLLocationCoordinate2D)fromLoc toCoordinate:(CLLocationCoordinate2D)toLoc
{
    float fLat = degreesToRadians(fromLoc.latitude);
    float fLng = degreesToRadians(fromLoc.longitude);
    float tLat = degreesToRadians(toLoc.latitude);
    float tLng = degreesToRadians(toLoc.longitude);
    
    float degree = atan2(sin(tLng-fLng)*cos(tLat), cos(fLat)*sin(tLat)-sin(fLat)*cos(tLat)*cos(tLng-fLng));
    
    float deg  = radiandsToDegrees(degree);
    NSLog(@"%f",deg);
    
    return degreesToRadians(deg);
}



#pragma mark - XML parsing

-(void)dataForParsing:(NSArray *)gpxFileName {
    
    NSString *gpxFilePathFirst = [[NSBundle mainBundle] pathForResource:gpxFileName[0] ofType:@"gpx"];
    NSData *fileDataOne = [NSData dataWithContentsOfFile:gpxFilePathFirst];
    [self parseGPX:fileDataOne];
    NSString *gpxFilePathSecond = [[NSBundle mainBundle] pathForResource:gpxFileName[1] ofType:@"gpx"];
    NSData *fileDataTwo = [NSData dataWithContentsOfFile:gpxFilePathSecond];
    [self parseGPX:fileDataTwo];
    NSString *gpxFilePathThird = [[NSBundle mainBundle] pathForResource:gpxFileName[2] ofType:@"gpx"];
    NSData *fileDataThree = [NSData dataWithContentsOfFile:gpxFilePathThird];
    [self parseGPX:fileDataThree];


    
}

- (void)parseGPX:(NSData *)fileData{
    [GPXParser parse:fileData completion:^(BOOL success, GPX *gpx) {
        if (success) {
            NSLog(@"GPX success: %@", gpx);
            
            NSLog(@"GPX filename: %@", gpx.filename);
            NSLog(@"GPX waypoints: %@", gpx.waypoints);
            NSLog(@"GPX routes: %@", gpx.routes);
            NSLog(@"GPX tracks: %@", gpx.tracks);
            
            [self.theMapview removeAnnotations:self.theMapview.annotations];
            for (Track *thisTrack in gpx.tracks) {
                [self.theMapview addOverlay:thisTrack.path];
                
            }
            [self.theMapview setRegion:[self.theMapview regionThatFits:gpx.region] animated:YES];
            
        } else {
            NSLog(@"GPX fail for file");
        }
        j++;
        [self hello:gpx];
    }];
    
}

-(void)hello:(GPX *)gpx {
    if (j == 1) {
        for (Track *thisTrack in gpx.tracks) {
            arrayOfTrackList = thisTrack.fixes;
        }
    }
    else if(j == 2){
        for (Track *thisTrack in gpx.tracks) {
            arrayOfTrackListNew = thisTrack.fixes;
        }
    }
    else if(j==3) {
        for (Track *thisTrack in gpx.tracks) {
            arrayOfTrackListHome = thisTrack.fixes;
        }
    }
}


#pragma mark - Mapview delegates

- (MKOverlayRenderer*)mapView:(MKMapView*)mapView rendererForOverlay:(id <MKOverlay>)overlay {
    MKPolylineRenderer* lineView = [[MKPolylineRenderer alloc] initWithPolyline:overlay];
    lineView.strokeColor = [UIColor redColor];
    lineView.lineWidth = 3;
    return lineView;
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    
    MKAnnotationView *annotationView = [[MKAnnotationView alloc]init];
        annotationView.bounds = CGRectMake(0, 0, 10, 22.5);
        annotationView.transform = CGAffineTransformRotate(mapView.transform, degreeGlobal);
    return annotationView;
}


@end
