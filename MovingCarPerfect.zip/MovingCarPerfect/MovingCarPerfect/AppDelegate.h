//
//  AppDelegate.h
//  MovingCarPerfect
//
//  Created by Pavankumar on 01/08/16.
//  Copyright © 2016 Pavankumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

