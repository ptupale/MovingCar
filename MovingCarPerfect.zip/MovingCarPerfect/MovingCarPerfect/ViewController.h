//
//  ViewController.h
//  MovingCar
//
//  Created by Pavankumar on 17/06/16.
//  Copyright © 2016 NissiCalvin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

int j;
float degreeGlobal;
@interface ViewController : UIViewController<MKAnnotation>
@property (strong, nonatomic) IBOutlet MKMapView *theMapview;

- (IBAction)addCarActon:(id)sender;

@property (strong, nonatomic) NSMutableArray *arrayOfTrackListHome;


@end

